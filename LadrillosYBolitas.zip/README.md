LadrillosYBolitas

Mirar canvas raro ese que ha dicho de proyeccion
Spawner de pelotas
Gamefield  Un gameObject en la escena que si ponemos un prefab en el 0,0, se ponga en la esquina inferior izquierda

//Componentes
BallSpaw, sumidero, deathZone,constructor(creador mapa), detector de input

Tile con metodos virtuales

